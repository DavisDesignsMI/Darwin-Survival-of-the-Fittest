/*
CREATED BY: Davis M Brace (Davis Designs of Michigan LLC)
STARTED ON: 4/30/2019

DESCRIPTION:
Simulates a post-apocalyptic survival scenario.

NOTES:
Designed to be open-source, so all actions are housed within external functions to allow for easy editing and reuse.
 */
package com.davisdesignsmi.darwinsurvivalofthefittest

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import kotlin.random.Random.Default.nextInt

class MainActivity : AppCompatActivity() {

    //Initiate status variables
    var health = 100
    var hunger = 100
    var thirst = 100

    //Initiate object count variables
    var parts = 2
    var food = 10
    var water = 10
    var wood = 10
    var flint = false
    var fire = false
    var trap = false
    var flintUses = 0

    //Initiate labels
    private var CParts: TextView? = null
    private  var Food: TextView? = null
    private  var Water: TextView? = null
    private  var Wood: TextView? = null
    private var Fire: TextView? = null
    private var Flint: TextView? = null

    //====================================================================================
    //====================================================================================
    //====================================================================================

    //Tell something to the user
    fun say(a: String)
    {
        Toast.makeText(this, a, Toast.LENGTH_LONG).show()
    }

    //====================================================================================
    //====================================================================================
    //====================================================================================

    //Update display
    fun  update()
    {
        //Initialize labels
        CParts = findViewById(R.id.CParts)
        Food = findViewById(R.id.Food)
        Water = findViewById(R.id.Water)
        Wood = findViewById(R.id.Wood)
        Fire = findViewById(R.id.Fire)
        Flint = findViewById(R.id.Flint)
        //Set labels
        CParts?.text = "Car Parts: " + parts
        Food?.text = "Food: " + food
        Water?.text = "Water: " + water
        Wood?.text = "Wood: " + wood

        if (fire)
        {
            Fire?.text = "Fire On"
        }
        else
        {
            Fire?.text = null
        }

        if (flint)
        {
            Flint?.text = "Flint Uses:" + flintUses.toString()
        }
        else
        {
            Flint?.text = null
        }

        //Initialize progress bars
        val HealthBar: ProgressBar = findViewById(R.id.HealthBar)
        val HungerBar: ProgressBar = findViewById(R.id.HungerBar)
        val hungerBar: ProgressBar = findViewById(R.id.hungerBar)
        //Set progress bars
        HealthBar.progress = health
        HungerBar.progress = hunger
        hungerBar.progress = thirst

        if (flint && flintUses > 10)
        {
            flint = false
            say("Your flint broke!")
        }

        if (health <= 20)
        {
            say("You're dying!")
        }

        if (hunger >= 80 && thirst >= 80 && health <= 90)
        {
            health += 10
        }

        if (health <= 0)
        {
            lose()
        }
    }

    //====================================================================================
    //====================================================================================
    //====================================================================================

    //Do maintenance on action
    fun upTick()
    {
        if (hunger > 0 && thirst > 0) {
            hunger -= 5
            thirst -= 5
        }
        else if (hunger <= 0)
        {
            health -= 5
        }
        else if (thirst <= 0)
        {
            health -= 5

            if (hunger > 0) {
                hunger -= 5
            } else {
                health -= 5
            }
        }

        if (fire)
        {
            if (wood >= 5)
            {
                wood -= 5
            }
            else
            {
                fire = false
                say("You need wood!")
            }
        }
        else if (fire.not())
        {
            health -= 20
        }

        if (trap)
        {
            food += 2
        }

        update()
    }

    //====================================================================================
    //====================================================================================
    //====================================================================================

    fun eat()
    {
        if (food >= 5 && hunger <= 90)
        {
            food -= 5
            hunger += 10
        }
        else if (hunger > 90)
        {
            say("You are full!")
        }
        else
        {
            say("Not enough food!")
        }

        update()
    }

    //====================================================================================
    //====================================================================================
    //====================================================================================

    fun drink()
    {
        if (water >= 5 && thirst <= 90)
        {
            water -= 5
            thirst += 10
        }
        else if (thirst > 90)
        {
            say("You are not thirsty!")
        }
        else
        {
            say("Not enough water!")
        }

        update()
    }

    //====================================================================================
    //====================================================================================
    //====================================================================================

    fun scavenge()
    {
        var rand1 = nextInt(1, 6)
        var rand2 = nextInt(1,21)

        var rand3 = nextInt(1,20)

        if (rand3 == 15)
        {
            parts += 1
        }

        when (rand1) {
            1 ->
            {
                wood += rand2
                say("You found $rand2 wood!")
            }
            2 ->
            {
                food += rand2
                say("You found $rand2 food!")
            }
            3 ->
            {
                water += rand2
                say("You found $rand2 water!")
            }
            4 ->
            {
                wood += rand2
                say("You found $rand2 wood!")
            }
            5 ->
            {
                wood += rand2
                food += 10
                water += 15

                say("You hit the motherlode!")
            }
            6 ->
            {
                wood += rand2
                say("You found $rand2 wood!")
            }
        }
    }

    //====================================================================================
    //====================================================================================
    //====================================================================================

    fun buildFlint()
    {
        update()

        if (flint)
        {
            say("You already have flint!")
        }
        else if (parts >= 1)
        {
            parts -= 1
            flint = true
            flintUses = 0
        }
    }

    //====================================================================================
    //====================================================================================
    //====================================================================================

    fun buildTrap()
    {
        if (wood >= 5 && parts >= 1 && trap.not())
        {
            wood -= 5
            parts -= 1
            trap = true
        }
        else if (trap.not())
        {
            say("Not enough resources!")
        }
        else
        {
            say("Trap already built!")
        }
    }

    //====================================================================================
    //====================================================================================
    //====================================================================================

    fun startFire()
    {
        if (flint && wood >= 10 && fire.not())
        {
            flintUses += 1
            update()
            fire = true
        }
    }

    //====================================================================================
    //====================================================================================
    //====================================================================================

    fun lose()
    {
        //Reset status variables
        health = 100
        hunger = 100
        thirst = 100

        //Reset object count variables
        parts = 2
        food = 10
        water = 10
        wood = 10
        flint = false
        fire = false
        trap = false
        flintUses = 0

        //Inform user of loss
        say("You have died!!!!!!  Respawning...")

        //update labels
        update()
    }

    //====================================================================================
    //====================================================================================
    //====================================================================================

    override fun onCreate(savedInstanceState: Bundle?)
    {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        update()

        val btnScavenge: Button = findViewById(R.id.btnScavenge)
        val btnEat: Button = findViewById(R.id.btnEat)
        val btnDrink: Button = findViewById(R.id.btnDrink)
        val btnflint: Button = findViewById(R.id.btnflint)
        val btnFire: Button = findViewById(R.id.btnFire)
        val btnTrap: Button = findViewById(R.id.btnTrap)

        //====================================================================================

        btnEat.setOnClickListener(object : View.OnClickListener
        {
            override fun onClick(v: View?) {
                eat()
                update()
            }
        })

        //====================================================================================

        btnDrink.setOnClickListener(object : View.OnClickListener
        {
            override fun onClick(v: View?) {
                drink()
                update()
            }
        })

        //====================================================================================

        btnScavenge.setOnClickListener(object : View.OnClickListener
        {
            override fun onClick(v: View?) {
                scavenge()
                upTick()
            }
        })

        //====================================================================================

        btnflint.setOnClickListener(object : View.OnClickListener
        {
            override fun onClick(v: View?) {
                buildFlint()
                upTick()
            }
        })

        //====================================================================================

        btnFire.setOnClickListener(object : View.OnClickListener
        {
            override fun onClick(v: View?) {
                startFire()
                upTick()
            }
        })

        //====================================================================================

        btnTrap.setOnClickListener(object : View.OnClickListener
        {
            override fun onClick(v: View?) {
                buildTrap()
                upTick()
            }
        })
    }
}
